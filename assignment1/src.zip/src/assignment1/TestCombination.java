/**
 * 
 */
package assignment1;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * @author Jens Fredskov, Henrik Bendt
 *
 */
public class TestCombination {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test method for {@link assignment1.Employee#AddSalary(int)}.
	 */
	@Test
	public void testAddSalary() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link assignment1.Employee#MinAge(int)}.
	 */
	@Test
	public void testMinAge() {
		fail("Not yet implemented");
	}

}
